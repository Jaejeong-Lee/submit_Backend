package lecture.book;

public class Application2 {
    public static void main(String[] args) {
        Book myBook1 = new Book();
        Book myBook2 = new Book("재정","자바좋아");
        Book myBook3 = new Book("재정","자바좋아",55,"하드커버");
    }
}
