package ch06.sec06.exam02;

public class KoreanExample {
    public static void main(String[] args) {
        // Korean 객체 생성
        Korean person1 = new Korean();
        person1.name = "박자바";
        person1.ssn = "011225-1234567";

        // 또 다른 Korean 객체 생성
        Korean person2 = new Korean();
        person2.name = "김자바";
        person2.ssn = "930525-0654321";
    }
}
